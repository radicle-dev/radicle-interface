## Loading a image with a relative path

![Black Square](./assets/black-square.png)
