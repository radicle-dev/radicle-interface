## Example paths

[Markdown Cheatsheet](cheatsheet.md)  
[black square](./assets/black-square.png)  
[Footnotes](/footnotes.md)  
[Absolute Link](/relative-files/linked-file.md)
