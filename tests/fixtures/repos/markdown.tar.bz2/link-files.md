## Example paths

[Markdown Cheatsheet](cheatsheet.md)  
[black square ⬛️](./assets/black-square.png)
