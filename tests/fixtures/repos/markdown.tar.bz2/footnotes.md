# footnotes

This is an example footnote[^1]. And some radicle[^2] examples.[^3]

[^1]: https://example.com
[^2]: https://radicle.xyz

[^3]: A corporeal grounding, though one hardly to the exclusion of the _cerebral_ as in the erroneous sense of a mind/body dichotomy, except insofar as what is most squarely in the cerebral would land here only on the periphery of our focus.
